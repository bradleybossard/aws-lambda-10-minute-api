# aws-lambda-10-minute-api
Following along with tutorial on building an API with Amazon Lambda functions

[How To Build An API In 10 Minutes](http://readwrite.com/2015/11/16/how-to-build-an-api-amazon-lambda)
